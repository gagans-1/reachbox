export function Toast({
  message,
  variant = 'error',
  onDismiss,
}: {
  message: string;
  variant?: 'error' | 'success';
  onDismiss: () => void;
}) {
  const styles = variant === 'error' ? 'bg-red-50 text-red-700 border-red-200' : 'bg-green-50 text-green-700 border-green-200';
  return (
    <div className={`fixed bottom-4 right-4 z-50 flex items-center gap-3 rounded-lg border px-4 py-3 shadow-md ${styles}`}>
      <span className="text-sm">{message}</span>
      <button onClick={onDismiss} className="text-xs opacity-60 hover:opacity-100">
        ✕
      </button>
    </div>
  );
}
