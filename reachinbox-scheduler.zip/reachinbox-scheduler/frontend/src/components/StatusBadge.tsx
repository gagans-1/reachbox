import type { EmailStatus } from '@/types';

const STYLES: Record<EmailStatus, string> = {
  scheduled: 'bg-blue-100 text-blue-700',
  rescheduled: 'bg-amber-100 text-amber-700',
  sending: 'bg-purple-100 text-purple-700',
  sent: 'bg-green-100 text-green-700',
  failed: 'bg-red-100 text-red-700',
};

export function StatusBadge({ status }: { status: EmailStatus }) {
  return (
    <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-medium ${STYLES[status] || 'bg-gray-100 text-gray-700'}`}>
      {status}
    </span>
  );
}
