import { Button } from '@/components/Button';
import { api } from '@/lib/api';

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4">
      <div className="w-full max-w-sm rounded-2xl border border-gray-200 bg-white p-8 text-center shadow-sm">
        <h1 className="text-xl font-semibold text-gray-900">ReachInbox Scheduler</h1>
        <p className="mt-1 text-sm text-gray-500">Sign in to manage your email campaigns.</p>
        <Button className="mt-6 w-full" onClick={() => (window.location.href = api.loginUrl())}>
          Continue with Google
        </Button>
      </div>
    </div>
  );
}
