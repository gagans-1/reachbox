import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/router';
import { api } from '@/lib/api';
import type { ScheduledEmail, SentEmail, User } from '@/types';
import { Button } from '@/components/Button';
import { Table, Column } from '@/components/Table';
import { StatusBadge } from '@/components/StatusBadge';
import { EmptyState } from '@/components/EmptyState';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { ComposeEmailModal } from '@/components/ComposeEmailModal';
import { Toast } from '@/components/Toast';

type Tab = 'scheduled' | 'sent';

export default function Dashboard() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [tab, setTab] = useState<Tab>('scheduled');
  const [scheduled, setScheduled] = useState<ScheduledEmail[] | null>(null);
  const [sent, setSent] = useState<SentEmail[] | null>(null);
  const [query, setQuery] = useState('');
  const [composeOpen, setComposeOpen] = useState(false);
  const [slackConnected, setSlackConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .me()
      .then(setUser)
      .catch(() => router.replace('/login'));
    api.slackStatus().then((s) => setSlackConnected(s.connected)).catch(() => {});
  }, [router]);

  const loadScheduled = useCallback(() => {
    setScheduled(null);
    api
      .scheduledEmails(query)
      .then((r) => setScheduled(r.emails))
      .catch((err) => setError(err.message));
  }, [query]);

  const loadSent = useCallback(() => {
    setSent(null);
    api
      .sentEmails(query)
      .then((r) => setSent(r.emails))
      .catch((err) => setError(err.message));
  }, [query]);

  useEffect(() => {
    if (tab === 'scheduled') loadScheduled();
    else loadSent();
  }, [tab, loadScheduled, loadSent]);

  async function handleLogout() {
    await api.logout();
    router.replace('/login');
  }

  const scheduledColumns: Column<ScheduledEmail>[] = [
    { key: 'email', header: 'Email', render: (r) => r.email },
    { key: 'subject', header: 'Subject', render: (r) => r.subject },
    {
      key: 'scheduledTime',
      header: 'Scheduled time',
      render: (r) => new Date(r.scheduledTime).toLocaleString(),
    },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
  ];

  const sentColumns: Column<SentEmail>[] = [
    { key: 'email', header: 'Email', render: (r) => r.email },
    { key: 'subject', header: 'Subject', render: (r) => r.subject },
    {
      key: 'sentTime',
      header: 'Sent time',
      render: (r) => (r.sentTime ? new Date(r.sentTime).toLocaleString() : '—'),
    },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="flex items-center justify-between border-b border-gray-200 bg-white px-6 py-4">
        <h1 className="text-lg font-semibold">ReachInbox Scheduler</h1>
        <div className="flex items-center gap-4">
          {!slackConnected && (
            <a href={api.slackConnectUrl()} className="text-sm font-medium text-brand-600 hover:underline">
              Connect Slack
            </a>
          )}
          {user && (
            <div className="flex items-center gap-2">
              {user.avatar_url && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={user.avatar_url} alt={user.name} className="h-8 w-8 rounded-full" />
              )}
              <div className="text-sm">
                <p className="font-medium leading-tight">{user.name}</p>
                <p className="text-gray-500 leading-tight">{user.email}</p>
              </div>
            </div>
          )}
          <Button variant="ghost" onClick={handleLogout}>
            Logout
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-6 py-8">
        <div className="mb-6 flex items-center justify-between">
          <div className="flex gap-2 rounded-lg bg-gray-100 p-1">
            <button
              onClick={() => setTab('scheduled')}
              className={`rounded-md px-4 py-1.5 text-sm font-medium ${
                tab === 'scheduled' ? 'bg-white shadow-sm' : 'text-gray-500'
              }`}
            >
              Scheduled Emails
            </button>
            <button
              onClick={() => setTab('sent')}
              className={`rounded-md px-4 py-1.5 text-sm font-medium ${
                tab === 'sent' ? 'bg-white shadow-sm' : 'text-gray-500'
              }`}
            >
              Sent Emails
            </button>
          </div>
          <Button onClick={() => setComposeOpen(true)}>+ Compose New Email</Button>
        </div>

        <input
          className="mb-4 w-full max-w-sm rounded-lg border border-gray-300 px-3 py-2 text-sm"
          placeholder="Search emails…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />

        {tab === 'scheduled' &&
          (scheduled === null ? (
            <LoadingSpinner label="Loading scheduled emails…" />
          ) : scheduled.length === 0 ? (
            <EmptyState title="No scheduled emails" description="Compose a new email to get started." />
          ) : (
            <Table columns={scheduledColumns} rows={scheduled} rowKey={(r) => r.id} />
          ))}

        {tab === 'sent' &&
          (sent === null ? (
            <LoadingSpinner label="Loading sent emails…" />
          ) : sent.length === 0 ? (
            <EmptyState title="No sent emails yet" description="Emails will appear here once they go out." />
          ) : (
            <Table columns={sentColumns} rows={sent} rowKey={(r) => r.id} />
          ))}
      </main>

      <ComposeEmailModal
        open={composeOpen}
        onClose={() => setComposeOpen(false)}
        onScheduled={() => {
          setTab('scheduled');
          loadScheduled();
        }}
      />

      {error && <Toast message={error} onDismiss={() => setError(null)} />}
    </div>
  );
}
