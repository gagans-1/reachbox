export interface User {
  id: string;
  name: string;
  email: string;
  avatar_url: string | null;
}

export type EmailStatus = 'scheduled' | 'rescheduled' | 'sending' | 'sent' | 'failed';

export interface ScheduledEmail {
  id: string;
  email: string;
  subject: string;
  scheduledTime: string;
  status: EmailStatus;
}

export interface SentEmail {
  id: string;
  email: string;
  subject: string;
  sentTime: string | null;
  status: EmailStatus;
}

export interface ScheduleFormValues {
  subject: string;
  body: string;
  startTime: string;
  delayMs: number;
  hourlyLimit: number;
  file: File | null;
}
