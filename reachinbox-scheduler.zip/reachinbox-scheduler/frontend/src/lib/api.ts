import type { ScheduledEmail, SentEmail, User } from '@/types';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    credentials: 'include',
    ...options,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  return res.json();
}

export const api = {
  loginUrl: () => `${API_BASE}/auth/google`,
  slackConnectUrl: () => `${API_BASE}/slack/oauth/start`,

  me: () => request<User>('/auth/me'),
  logout: () => request<{ ok: true }>('/auth/logout', { method: 'POST' }),
  slackStatus: () => request<{ connected: boolean; teamName: string | null }>('/slack/status'),

  scheduledEmails: (q?: string) =>
    request<{ emails: ScheduledEmail[] }>(`/emails/scheduled${q ? `?q=${encodeURIComponent(q)}` : ''}`),
  sentEmails: (q?: string) =>
    request<{ emails: SentEmail[] }>(`/emails/sent${q ? `?q=${encodeURIComponent(q)}` : ''}`),

  parseLeads: async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return request<{ count: number; emails: string[] }>('/leads/parse', {
      method: 'POST',
      body: formData,
    });
  },

  scheduleCampaign: async (params: {
    subject: string;
    body: string;
    startTime: string;
    delayMs: number;
    hourlyLimit: number;
    file: File;
  }) => {
    const formData = new FormData();
    formData.append('subject', params.subject);
    formData.append('body', params.body);
    formData.append('startTime', params.startTime);
    formData.append('delayMs', String(params.delayMs));
    formData.append('hourlyLimit', String(params.hourlyLimit));
    formData.append('file', params.file);
    return request<{ campaignId: string; scheduled: number }>('/schedule', {
      method: 'POST',
      body: formData,
    });
  },
};
