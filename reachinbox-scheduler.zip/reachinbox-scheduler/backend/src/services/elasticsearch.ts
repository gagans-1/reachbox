import { Client } from '@elastic/elasticsearch';
import { env } from '../config/env';

export const esClient = new Client({ node: env.esNode });

export async function ensureEmailIndex() {
  const exists = await esClient.indices.exists({ index: env.esIndex });
  if (!exists) {
    await esClient.indices.create({
      index: env.esIndex,
      mappings: {
        properties: {
          userId: { type: 'keyword' },
          recipient: { type: 'text' },
          subject: { type: 'text' },
          body: { type: 'text' },
          status: { type: 'keyword' },
          scheduledAt: { type: 'date' },
          sentAt: { type: 'date' },
        },
      },
    });
  }
}

export interface IndexableEmail {
  id: string;
  userId: string;
  recipient: string;
  subject: string;
  body: string;
  status: string;
  scheduledAt: string;
  sentAt: string | null;
}

/** Upsert one email document. Called on create, and again on send/fail. */
export async function indexEmail(email: IndexableEmail) {
  await esClient.index({
    index: env.esIndex,
    id: email.id,
    document: email,
  });
}

export async function searchEmails(userId: string, query: string) {
  const result = await esClient.search({
    index: env.esIndex,
    query: {
      bool: {
        must: [{ term: { userId } }],
        should: [
          { match: { subject: query } },
          { match: { body: query } },
          { match: { recipient: query } },
        ],
        minimum_should_match: query ? 1 : 0,
      },
    },
  });
  return result.hits.hits.map((h) => h._source);
}
