import { pool } from '../db/pool';

/**
 * Sends a live Slack message the moment a sender's hourly limit is hit.
 * If the user hasn't connected Slack, this is a silent no-op (no crash) —
 * satisfies "handle disconnect: rate-limit hits should simply not notify".
 * Because we look the connection up fresh from Postgres on every call
 * (rather than caching it in memory), a user who connects Slack *after*
 * some rate-limit hits will start getting notified immediately, with no
 * redeploy required.
 */
export async function notifyRateLimitHit(userId: string, senderEmail: string, hourlyLimit: number) {
  const { rows } = await pool.query(
    `SELECT access_token, webhook_url, channel_id FROM slack_connections WHERE user_id = $1`,
    [userId]
  );

  if (rows.length === 0) {
    return; // no Slack connection — silently skip
  }

  const { webhook_url, access_token, channel_id } = rows[0];
  const text = `:rotating_light: Hourly send limit reached for *${senderEmail}* (${hourlyLimit}/hr). Remaining emails have been rescheduled to the next hour window.`;

  try {
    if (webhook_url) {
      await fetch(webhook_url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
    } else if (access_token && channel_id) {
      await fetch('https://slack.com/api/chat.postMessage', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${access_token}`,
        },
        body: JSON.stringify({ channel: channel_id, text }),
      });
    }
  } catch (err) {
    // A failed Slack call should never take down the worker.
    console.error('Slack notification failed:', err);
  }
}
