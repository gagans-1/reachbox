import { redisConnection } from '../queue/connection';
import { pool } from '../db/pool';

/**
 * Per-sender hourly rate limiting.
 *
 * Why Redis INCR and not an in-memory counter:
 * - Multiple worker processes/instances share one Redis, so INCR is atomic
 *   and globally consistent regardless of which process handles the job.
 * - Keys are windowed by hour (`ratelimit:<senderId>:<hourBucket>`) and
 *   expire automatically (TTL) so we never need manual cleanup.
 * - We also mirror the count into Postgres (rate_limit_counters) for
 *   auditing/reporting in the dashboard; Redis is the source of truth for
 *   the gating decision because it's fast and atomic.
 */

function hourBucket(date: Date): string {
  // Truncate to the top of the hour, e.g. 2026-09-05T14:00:00Z -> "2026090514"
  return `${date.getUTCFullYear()}${String(date.getUTCMonth() + 1).padStart(2, '0')}${String(
    date.getUTCDate()
  ).padStart(2, '0')}${String(date.getUTCHours()).padStart(2, '0')}`;
}

function hourWindowStart(date: Date): Date {
  const d = new Date(date);
  d.setUTCMinutes(0, 0, 0);
  return d;
}

/**
 * Atomically attempts to reserve one "send slot" for `senderId` in the
 * current hour window. Returns true if under limit (and increments), false
 * if the hourly limit has already been reached.
 */
export async function tryReserveSendSlot(
  senderId: string,
  maxPerHour: number,
  at: Date = new Date()
): Promise<boolean> {
  const bucket = hourBucket(at);
  const key = `ratelimit:${senderId}:${bucket}`;

  // INCR is atomic in Redis; we read the *post-increment* value to decide.
  const count = await redisConnection.incr(key);
  if (count === 1) {
    // First hit in this window — set expiry so the key self-cleans (~2h buffer).
    await redisConnection.expire(key, 7200);
  }

  if (count > maxPerHour) {
    // Over budget: undo our reservation so a later slot in this same
    // window can still be claimed by someone else's retry, and mirror
    // nothing extra to Postgres for this attempt.
    await redisConnection.decr(key);
    return false;
  }

  // Mirror to Postgres for the dashboard / audit trail (best-effort).
  const windowStart = hourWindowStart(at);
  await pool.query(
    `INSERT INTO rate_limit_counters (sender_id, hour_window, sent_count)
     VALUES ($1, $2, 1)
     ON CONFLICT (sender_id, hour_window)
     DO UPDATE SET sent_count = rate_limit_counters.sent_count + 1`,
    [senderId, windowStart]
  );

  return true;
}

/** Returns the start of the *next* hour window after `at`. */
export function nextHourWindow(at: Date = new Date()): Date {
  const d = hourWindowStart(at);
  d.setUTCHours(d.getUTCHours() + 1);
  return d;
}
