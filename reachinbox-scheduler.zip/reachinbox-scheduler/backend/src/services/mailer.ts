import nodemailer from 'nodemailer';

export interface SenderCreds {
  smtpUser: string;
  smtpPass: string;
  smtpHost: string;
  smtpPort: number;
  fromAddress: string;
}

/** Creates a fresh Ethereal test account (used when a sender is first added). */
export async function createEtherealSender() {
  const testAccount = await nodemailer.createTestAccount();
  return {
    smtpUser: testAccount.user,
    smtpPass: testAccount.pass,
    smtpHost: testAccount.smtp.host,
    smtpPort: testAccount.smtp.port,
    fromAddress: testAccount.user,
  };
}

export async function sendMail(
  creds: SenderCreds,
  to: string,
  subject: string,
  html: string
): Promise<{ messageId: string; previewUrl: string | false }> {
  const transporter = nodemailer.createTransport({
    host: creds.smtpHost,
    port: creds.smtpPort,
    secure: false,
    auth: { user: creds.smtpUser, pass: creds.smtpPass },
  });

  const info = await transporter.sendMail({
    from: creds.fromAddress,
    to,
    subject,
    html,
  });

  return { messageId: info.messageId, previewUrl: nodemailer.getTestMessageUrl(info) };
}
