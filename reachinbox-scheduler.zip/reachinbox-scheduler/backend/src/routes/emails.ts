import { Router } from 'express';
import { pool } from '../db/pool';
import { requireAuth } from '../middleware/auth';
import { searchEmails } from '../services/elasticsearch';

const router = Router();

router.get('/emails/scheduled', requireAuth, async (req, res) => {
  const userId = (req.session as any).userId;
  const q = (req.query.q as string) || '';

  if (q) {
    const hits = await searchEmails(userId, q);
    return res.json({
      emails: hits.filter((h: any) => h.status === 'scheduled' || h.status === 'rescheduled'),
    });
  }

  const { rows } = await pool.query(
    `SELECT id, recipient as email, subject, scheduled_at as "scheduledTime", status
     FROM emails WHERE user_id = $1 AND status IN ('scheduled','rescheduled','sending')
     ORDER BY scheduled_at ASC LIMIT 500`,
    [userId]
  );
  res.json({ emails: rows });
});

router.get('/emails/sent', requireAuth, async (req, res) => {
  const userId = (req.session as any).userId;
  const q = (req.query.q as string) || '';

  if (q) {
    const hits = await searchEmails(userId, q);
    return res.json({ emails: hits.filter((h: any) => h.status === 'sent' || h.status === 'failed') });
  }

  const { rows } = await pool.query(
    `SELECT id, recipient as email, subject, sent_at as "sentTime", status
     FROM emails WHERE user_id = $1 AND status IN ('sent','failed')
     ORDER BY sent_at DESC LIMIT 500`,
    [userId]
  );
  res.json({ emails: rows });
});

export default router;
