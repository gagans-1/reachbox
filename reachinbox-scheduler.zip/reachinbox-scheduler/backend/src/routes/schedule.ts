import { Router } from 'express';
import multer from 'multer';
import { v4 as uuidv4 } from 'uuid';
import { pool } from '../db/pool';
import { requireAuth } from '../middleware/auth';
import { enqueueEmail } from '../queue/emailQueue';
import { indexEmail } from '../services/elasticsearch';

const router = Router();
const upload = multer({ storage: multer.memoryStorage() });

const EMAIL_REGEX = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;

function extractEmails(fileText: string): string[] {
  const matches = fileText.match(EMAIL_REGEX) || [];
  return Array.from(new Set(matches.map((e) => e.trim().toLowerCase())));
}

// POST /leads/parse — upload a CSV/text file, just get the count + preview back
// (used by the compose form before the user hits "Schedule").
router.post('/leads/parse', requireAuth, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const text = req.file.buffer.toString('utf-8');
  const emails = extractEmails(text);
  res.json({ count: emails.length, emails });
});

// POST /schedule — the main "Compose New Email" -> "Schedule" action.
router.post('/schedule', requireAuth, upload.single('file'), async (req, res) => {
  const userId = (req.session as any).userId;
  const { subject, body, startTime, delayMs, hourlyLimit } = req.body;

  if (!req.file) return res.status(400).json({ error: 'Lead file is required' });
  if (!subject || !body || !startTime) {
    return res.status(400).json({ error: 'subject, body and startTime are required' });
  }

  const recipients = extractEmails(req.file.buffer.toString('utf-8'));
  if (recipients.length === 0) {
    return res.status(400).json({ error: 'No valid email addresses found in the uploaded file' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const senderRes = await client.query(
      `SELECT id, max_emails_per_hour FROM senders WHERE user_id = $1 LIMIT 1`,
      [userId]
    );
    if (senderRes.rows.length === 0) throw new Error('No sender configured for this user');
    const senderId = senderRes.rows[0].id;

    const parsedHourlyLimit = parseInt(hourlyLimit, 10) || senderRes.rows[0].max_emails_per_hour;
    // Update the sender's configured hourly limit (kept configurable via
    // the UI/env, never hardcoded).
    await client.query(`UPDATE senders SET max_emails_per_hour = $1 WHERE id = $2`, [
      parsedHourlyLimit,
      senderId,
    ]);

    const campaignRes = await client.query(
      `INSERT INTO campaigns (user_id, sender_id, subject, body, start_time, delay_ms, hourly_limit, total_recipients)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
      [
        userId,
        senderId,
        subject,
        body,
        new Date(startTime),
        parseInt(delayMs, 10) || 2000,
        parsedHourlyLimit,
        recipients.length,
      ]
    );
    const campaignId = campaignRes.rows[0].id;

    const delayBetween = parseInt(delayMs, 10) || 2000;
    const start = new Date(startTime).getTime();

    const emailRows: { id: string; recipient: string; scheduledAt: Date }[] = [];

    for (let i = 0; i < recipients.length; i++) {
      const emailId = uuidv4();
      const scheduledAt = new Date(start + i * delayBetween);
      emailRows.push({ id: emailId, recipient: recipients[i], scheduledAt });
    }

    // Bulk insert the per-recipient rows.
    const values: any[] = [];
    const placeholders = emailRows
      .map((row, i) => {
        const base = i * 8;
        values.push(
          row.id,
          campaignId,
          userId,
          senderId,
          row.recipient,
          subject,
          body,
          row.scheduledAt
        );
        return `($${base + 1},$${base + 2},$${base + 3},$${base + 4},$${base + 5},$${base + 6},$${base + 7},$${base + 8})`;
      })
      .join(',');

    await client.query(
      `INSERT INTO emails (id, campaign_id, user_id, sender_id, recipient, subject, body, scheduled_at)
       VALUES ${placeholders}`,
      values
    );

    await client.query('COMMIT');

    // Enqueue BullMQ delayed jobs *after* commit succeeds, so we never have
    // jobs referencing rows that failed to persist.
    for (const row of emailRows) {
      await enqueueEmail(
        { emailId: row.id, senderId, recipient: row.recipient, subject, body },
        row.scheduledAt
      );
      indexEmail({
        id: row.id,
        userId,
        recipient: row.recipient,
        subject,
        body,
        status: 'scheduled',
        scheduledAt: row.scheduledAt.toISOString(),
        sentAt: null,
      }).catch((err) => console.error('ES index failed (non-fatal):', err));
    }

    res.json({ campaignId, scheduled: emailRows.length });
  } catch (err: any) {
    await client.query('ROLLBACK');
    console.error('Schedule failed:', err);
    res.status(500).json({ error: err.message || 'Failed to schedule emails' });
  } finally {
    client.release();
  }
});

export default router;
