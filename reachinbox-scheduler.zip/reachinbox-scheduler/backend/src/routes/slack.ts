import { Router } from 'express';
import { env } from '../config/env';
import { pool } from '../db/pool';
import { requireAuth } from '../middleware/auth';

const router = Router();

// Step 1: "Connect Slack" button hits this, redirects to Slack's real OAuth screen.
router.get('/slack/oauth/start', requireAuth, (req, res) => {
  const userId = (req.session as any).userId;
  const params = new URLSearchParams({
    client_id: env.slackClientId,
    scope: 'incoming-webhook,chat:write',
    redirect_uri: env.slackRedirectUri,
    state: userId, // carry the user id through the redirect round-trip
  });
  res.redirect(`https://slack.com/oauth/v2/authorize?${params.toString()}`);
});

// Step 2: Slack redirects back with ?code=...&state=<userId>
router.get('/slack/oauth/callback', async (req, res) => {
  try {
    const code = req.query.code as string;
    const userId = req.query.state as string;

    const tokenRes = await fetch('https://slack.com/api/oauth.v2.access', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: env.slackClientId,
        client_secret: env.slackClientSecret,
        code,
        redirect_uri: env.slackRedirectUri,
      }),
    });
    const data: any = await tokenRes.json();

    if (!data.ok) throw new Error(data.error || 'Slack OAuth exchange failed');

    const accessToken = data.access_token;
    const webhookUrl = data.incoming_webhook?.url || null;
    const channelId = data.incoming_webhook?.channel_id || null;
    const teamName = data.team?.name || null;

    await pool.query(
      `INSERT INTO slack_connections (user_id, access_token, webhook_url, channel_id, team_name)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (user_id) DO UPDATE SET access_token = $2, webhook_url = $3, channel_id = $4, team_name = $5`,
      [userId, accessToken, webhookUrl, channelId, teamName]
    );

    res.redirect(`${env.frontendUrl}/dashboard?slack=connected`);
  } catch (err) {
    console.error('Slack OAuth callback failed:', err);
    res.redirect(`${env.frontendUrl}/dashboard?slack=error`);
  }
});

router.get('/slack/status', requireAuth, async (req, res) => {
  const userId = (req.session as any).userId;
  const { rows } = await pool.query(
    `SELECT team_name FROM slack_connections WHERE user_id = $1`,
    [userId]
  );
  res.json({ connected: rows.length > 0, teamName: rows[0]?.team_name || null });
});

export default router;
