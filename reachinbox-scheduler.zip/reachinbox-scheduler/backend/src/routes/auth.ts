import { Router } from 'express';
import { OAuth2Client } from 'google-auth-library';
import { env } from '../config/env';
import { pool } from '../db/pool';
import { createEtherealSender } from '../services/mailer';

const router = Router();

const oauthClient = new OAuth2Client(
  env.googleClientId,
  env.googleClientSecret,
  env.googleCallbackUrl
);

// Step 1: redirect the browser to Google's real consent screen.
router.get('/auth/google', (req, res) => {
  const url = oauthClient.generateAuthUrl({
    access_type: 'online',
    scope: ['openid', 'profile', 'email'],
    prompt: 'select_account',
  });
  res.redirect(url);
});

// Step 2: Google redirects back here with a ?code=...
router.get('/auth/google/callback', async (req, res) => {
  try {
    const code = req.query.code as string;
    const { tokens } = await oauthClient.getToken(code);
    oauthClient.setCredentials(tokens);

    const ticket = await oauthClient.verifyIdToken({
      idToken: tokens.id_token!,
      audience: env.googleClientId,
    });
    const payload = ticket.getPayload();
    if (!payload) throw new Error('No payload from Google ID token');

    const googleId = payload.sub;
    const name = payload.name || payload.email || 'Unknown';
    const email = payload.email!;
    const avatarUrl = payload.picture || '';

    const { rows } = await pool.query(
      `INSERT INTO users (google_id, name, email, avatar_url)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (google_id) DO UPDATE SET name = $2, email = $3, avatar_url = $4
       RETURNING id`,
      [googleId, name, email, avatarUrl]
    );
    const userId = rows[0].id;

    // First-time login: provision a default Ethereal sender so the user
    // can immediately compose/schedule emails without extra setup steps.
    const existingSender = await pool.query(`SELECT id FROM senders WHERE user_id = $1 LIMIT 1`, [
      userId,
    ]);
    if (existingSender.rows.length === 0) {
      const creds = await createEtherealSender();
      await pool.query(
        `INSERT INTO senders (user_id, smtp_user, smtp_pass, smtp_host, smtp_port, from_address)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [userId, creds.smtpUser, creds.smtpPass, creds.smtpHost, creds.smtpPort, creds.fromAddress]
      );
    }

    (req.session as any).userId = userId;
    res.redirect(`${env.frontendUrl}/dashboard`);
  } catch (err) {
    console.error('Google OAuth callback failed:', err);
    res.redirect(`${env.frontendUrl}/login?error=oauth_failed`);
  }
});

// DEV/TEST ONLY: lets integration tests/local dev log in as an arbitrary
// user without going through real Google OAuth (useful in sandboxes with
// no network access to accounts.google.com). Inert unless the operator
// explicitly sets ALLOW_TEST_AUTH=true — never enable this in production.
if (process.env.ALLOW_TEST_AUTH === 'true') {
  router.post('/dev/login', async (req, res) => {
    const { userId } = req.body;
    if (!userId) return res.status(400).json({ error: 'userId required' });
    (req.session as any).userId = userId;
    res.json({ ok: true, userId });
  });
}

router.get('/auth/me', async (req, res) => {
  const userId = (req.session as any)?.userId;
  if (!userId) return res.status(401).json({ error: 'Not authenticated' });
  const { rows } = await pool.query(
    `SELECT id, name, email, avatar_url FROM users WHERE id = $1`,
    [userId]
  );
  if (rows.length === 0) return res.status(401).json({ error: 'Not authenticated' });
  res.json(rows[0]);
});

router.post('/auth/logout', (req, res) => {
  req.session = null;
  res.json({ ok: true });
});

export default router;
