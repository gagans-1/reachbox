// Augments Express's Request type so `req.session` is recognized everywhere
// without needing a custom AuthedRequest type in every route file.
// cookie-session attaches `session` dynamically at runtime; this just
// describes its shape (loosely) for TypeScript.
declare namespace Express {
  export interface Request {
    session: any;
  }
}
