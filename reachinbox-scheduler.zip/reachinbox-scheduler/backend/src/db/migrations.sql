-- Users authenticated via Google OAuth
CREATE TABLE IF NOT EXISTS users (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  google_id     TEXT UNIQUE NOT NULL,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL,
  avatar_url    TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Slack workspace connection per user (tenant)
CREATE TABLE IF NOT EXISTS slack_connections (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  access_token    TEXT NOT NULL,
  webhook_url     TEXT,
  channel_id      TEXT,
  team_name       TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

-- A "sender" is an Ethereal (or real SMTP) identity emails go out from.
-- Rate limits are tracked per sender so multiple senders don't share one bucket.
CREATE TABLE IF NOT EXISTS senders (
  id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  smtp_user              TEXT NOT NULL,
  smtp_pass              TEXT NOT NULL,
  smtp_host              TEXT NOT NULL DEFAULT 'smtp.ethereal.email',
  smtp_port              INTEGER NOT NULL DEFAULT 587,
  from_address            TEXT NOT NULL,
  max_emails_per_hour    INTEGER NOT NULL DEFAULT 200,
  created_at             TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- A batch = one "Compose New Email" submission (subject/body + uploaded lead list + schedule config)
CREATE TABLE IF NOT EXISTS campaigns (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  sender_id         UUID NOT NULL REFERENCES senders(id),
  subject           TEXT NOT NULL,
  body              TEXT NOT NULL,
  start_time        TIMESTAMPTZ NOT NULL,
  delay_ms          INTEGER NOT NULL,
  hourly_limit      INTEGER NOT NULL,
  total_recipients  INTEGER NOT NULL,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- One row per individual email (this is what BullMQ jobs correspond to 1:1)
CREATE TABLE IF NOT EXISTS emails (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id    UUID NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
  user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  sender_id      UUID NOT NULL REFERENCES senders(id),
  recipient      TEXT NOT NULL,
  subject        TEXT NOT NULL,
  body           TEXT NOT NULL,
  scheduled_at   TIMESTAMPTZ NOT NULL,
  sent_at        TIMESTAMPTZ,
  status         TEXT NOT NULL DEFAULT 'scheduled', -- scheduled | sending | sent | failed | rescheduled
  bullmq_job_id  TEXT,
  attempts       INTEGER NOT NULL DEFAULT 0,
  last_error     TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_emails_user_status ON emails(user_id, status);
CREATE INDEX IF NOT EXISTS idx_emails_campaign ON emails(campaign_id);
CREATE INDEX IF NOT EXISTS idx_emails_scheduled_at ON emails(scheduled_at);

-- Hourly send counters, keyed by sender + hour window. Backing store for
-- cross-process/cross-worker rate limiting (never rely on in-memory counts).
CREATE TABLE IF NOT EXISTS rate_limit_counters (
  sender_id     UUID NOT NULL REFERENCES senders(id) ON DELETE CASCADE,
  hour_window   TIMESTAMPTZ NOT NULL, -- truncated to the hour, e.g. 2026-09-05 14:00:00+00
  sent_count    INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (sender_id, hour_window)
);
