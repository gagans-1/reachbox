import { Worker, Job } from 'bullmq';
import { redisConnection } from './connection';
import { EMAIL_QUEUE_NAME, EmailJobData, enqueueEmail } from './emailQueue';
import { env } from '../config/env';
import { pool } from '../db/pool';
import { sendMail } from '../services/mailer';
import { tryReserveSendSlot, nextHourWindow } from '../services/rateLimiter';
import { notifyRateLimitHit } from '../services/slackNotifier';
import { indexEmail } from '../services/elasticsearch';

async function getSender(senderId: string) {
  const { rows } = await pool.query(
    `SELECT s.*, u.id as owner_id FROM senders s JOIN users u ON u.id = s.user_id WHERE s.id = $1`,
    [senderId]
  );
  return rows[0];
}

async function processJob(job: Job<EmailJobData>) {
  const { emailId, senderId, recipient, subject, body } = job.data;

  const sender = await getSender(senderId);
  if (!sender) throw new Error(`Sender ${senderId} not found`);

  // --- Rate limit gate -----------------------------------------------
  // Checked here (at send time), not at schedule time, because "1000+
  // emails scheduled for the same instant" must be spread out dynamically
  // as capacity frees up — not rejected up front.
  const allowed = await tryReserveSendSlot(senderId, sender.max_emails_per_hour);
  if (!allowed) {
    const nextWindow = nextHourWindow();
    await pool.query(`UPDATE emails SET status = 'rescheduled' WHERE id = $1`, [emailId]);

    // Re-enqueue into the next hour window. Reusing the BullMQ retry
    // mechanism here would multiply "attempts"; instead we add a fresh
    // delayed job for the same emailId once the old one is guaranteed done.
    await enqueueEmail({ emailId, senderId, recipient, subject, body }, nextWindow);

    await notifyRateLimitHit(sender.owner_id, sender.from_address, sender.max_emails_per_hour);

    // Not an error — this is expected backpressure, not a failure.
    return { rescheduled: true, nextWindow };
  }

  // --- Minimum delay between sends ------------------------------------
  // A floor on top of BullMQ's own concurrency, so even parallel workers
  // don't blast a single sender faster than the configured throttle.
  await new Promise((resolve) => setTimeout(resolve, env.minDelayMsBetweenSends));

  // --- Actually send ----------------------------------------------------
  await pool.query(`UPDATE emails SET status = 'sending' WHERE id = $1`, [emailId]);

  try {
    await sendMail(
      {
        smtpUser: sender.smtp_user,
        smtpPass: sender.smtp_pass,
        smtpHost: sender.smtp_host,
        smtpPort: sender.smtp_port,
        fromAddress: sender.from_address,
      },
      recipient,
      subject,
      body
    );

    const sentAt = new Date();
    await pool.query(
      `UPDATE emails SET status = 'sent', sent_at = $2, bullmq_job_id = $3 WHERE id = $1`,
      [emailId, sentAt, job.id]
    );

    await indexEmail({
      id: emailId,
      userId: sender.owner_id,
      recipient,
      subject,
      body,
      status: 'sent',
      scheduledAt: job.data as any,
      sentAt: sentAt.toISOString(),
    }).catch((err) => console.error('ES index failed (non-fatal):', err));

    return { sent: true };
  } catch (err: any) {
    await pool.query(`UPDATE emails SET status = 'failed', last_error = $2 WHERE id = $1`, [
      emailId,
      String(err?.message || err),
    ]);
    throw err; // let BullMQ's retry/backoff handle transient SMTP failures
  }
}

export const emailWorker = new Worker<EmailJobData>(EMAIL_QUEUE_NAME, processJob, {
  connection: redisConnection,
  concurrency: env.workerConcurrency, // configurable worker concurrency
});

emailWorker.on('failed', (job, err) => {
  console.error(`Job ${job?.id} failed:`, err.message);
});

emailWorker.on('completed', (job, result) => {
  console.log(`Job ${job.id} completed:`, result);
});

console.log(`Email worker started with concurrency=${env.workerConcurrency}`);
