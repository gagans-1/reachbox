import { Queue } from 'bullmq';
import { redisConnection } from './connection';

export interface EmailJobData {
  emailId: string;
  senderId: string;
  recipient: string;
  subject: string;
  body: string;
}

export const EMAIL_QUEUE_NAME = 'email-send-queue';

export const emailQueue = new Queue<EmailJobData>(EMAIL_QUEUE_NAME, {
  connection: redisConnection,
  defaultJobOptions: {
    attempts: 3,
    backoff: { type: 'exponential', delay: 5000 },
    removeOnComplete: 1000,
    removeOnFail: 5000,
  },
});

/**
 * Schedule a single email as a BullMQ delayed job.
 * Delay is computed from `sendAt` (absolute time), which is how we satisfy
 * "no cron" — BullMQ's own delayed-job mechanism (backed by Redis) tracks
 * the due time and survives restarts because jobs live in Redis, not memory.
 */
export async function enqueueEmail(data: EmailJobData, sendAt: Date) {
  const delay = Math.max(0, sendAt.getTime() - Date.now());
  // jobId = emailId guarantees idempotency: BullMQ refuses to create a
  // second job with the same id, so re-running the scheduler logic (e.g.
  // after a crash/retry) can never duplicate-send the same email.
  const job = await emailQueue.add('send-email', data, {
    delay,
    jobId: data.emailId,
  });
  return job;
}
