import express from 'express';
import cors from 'cors';
import cookieSession from 'cookie-session';
import { createBullBoard } from '@bull-board/api';
import { BullMQAdapter } from '@bull-board/api/bullMQAdapter';
import { ExpressAdapter } from '@bull-board/express';

import { env } from './config/env';
import { emailQueue } from './queue/emailQueue';
import { ensureEmailIndex } from './services/elasticsearch';

import authRoutes from './routes/auth';
import slackRoutes from './routes/slack';
import scheduleRoutes from './routes/schedule';
import emailsRoutes from './routes/emails';

async function main() {
  const app = express();

  app.use(cors({ origin: env.frontendUrl, credentials: true }));
  app.use(express.json());
  app.use(
    cookieSession({
      name: 'session',
      keys: [env.sessionSecret],
      maxAge: 7 * 24 * 60 * 60 * 1000,
    })
  );

  // Live BullMQ dashboard for real-time queue visibility (required).
  const serverAdapter = new ExpressAdapter();
  serverAdapter.setBasePath('/admin/queues');
  createBullBoard({
    queues: [new BullMQAdapter(emailQueue) as any],
    serverAdapter,
  });
  app.use('/admin/queues', serverAdapter.getRouter());

  app.use(authRoutes);
  app.use(slackRoutes);
  app.use(scheduleRoutes);
  app.use(emailsRoutes);

  app.get('/health', (_req, res) => res.json({ ok: true }));

  await ensureEmailIndex().catch((err) =>
    console.error('Elasticsearch index setup failed (is ES running?):', err)
  );

  app.listen(env.port, () => {
    console.log(`API listening on http://localhost:${env.port}`);
    console.log(`BullMQ dashboard: http://localhost:${env.port}/admin/queues`);
  });
}

main();
