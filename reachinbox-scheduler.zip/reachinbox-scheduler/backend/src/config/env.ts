import dotenv from 'dotenv';
dotenv.config();

function required(name: string, fallback?: string): string {
  const v = process.env[name] ?? fallback;
  if (v === undefined) {
    // We don't throw at import time for optional integrations (Google/Slack)
    // so local dev without those creds can still boot.
    return '';
  }
  return v;
}

export const env = {
  port: parseInt(process.env.PORT || '4000', 10),
  frontendUrl: required('FRONTEND_URL', 'http://localhost:3000'),
  sessionSecret: required('SESSION_SECRET', 'dev-secret'),

  databaseUrl: required('DATABASE_URL', 'postgres://postgres:postgres@localhost:5432/reachinbox'),

  redisHost: required('REDIS_HOST', 'localhost'),
  redisPort: parseInt(process.env.REDIS_PORT || '6379', 10),

  workerConcurrency: parseInt(process.env.WORKER_CONCURRENCY || '5', 10),
  minDelayMsBetweenSends: parseInt(process.env.MIN_DELAY_MS_BETWEEN_SENDS || '2000', 10),
  maxEmailsPerHourGlobal: parseInt(process.env.MAX_EMAILS_PER_HOUR || '200', 10),

  etherealUser: process.env.ETHEREAL_USER || '',
  etherealPass: process.env.ETHEREAL_PASS || '',

  esNode: required('ELASTICSEARCH_NODE', 'http://localhost:9200'),
  esIndex: required('ELASTICSEARCH_INDEX', 'emails'),

  googleClientId: process.env.GOOGLE_CLIENT_ID || '',
  googleClientSecret: process.env.GOOGLE_CLIENT_SECRET || '',
  googleCallbackUrl: required('GOOGLE_CALLBACK_URL', 'http://localhost:4000/auth/google/callback'),

  slackClientId: process.env.SLACK_CLIENT_ID || '',
  slackClientSecret: process.env.SLACK_CLIENT_SECRET || '',
  slackRedirectUri: required('SLACK_REDIRECT_URI', 'http://localhost:4000/slack/oauth/callback'),
};
